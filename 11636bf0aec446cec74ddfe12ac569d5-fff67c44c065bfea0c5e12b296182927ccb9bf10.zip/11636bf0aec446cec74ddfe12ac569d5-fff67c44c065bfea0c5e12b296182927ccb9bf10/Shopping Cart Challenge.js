var shoppingCart = [];

function addToCart(itemname,itemprice) {
  var item = {name : itemname, price : itemprice };
  shoppingCart.push(item);
}

addToCart("apple",2);
addToCart("pen",5);
addToCart("phone",200);
console.log(shoppingCart);

function priceCheck(name1) {
  for (var i = 0; i < shoppingCart.length ; i++) {
 if (name1 == shoppingCart[i].name) {
    console.log(name1 + " = " + shoppingCart[i].price);
  } else {
      console.log("the searched item is not in the shopping cart array");
  } 
}
}

priceCheck("apple");
priceCheck("phone");

function totalPriceCheck () {
for (var j = 0; j < shoppingCart.length; j++) {
var total = totalPriceCheck;
total += shoppingCart[j].price;
}
}

totalPriceCheck();

